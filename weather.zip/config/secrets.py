# config/secrets.py —— 不要提交、不要分发
# DASHSCOPE_API_KEY = "sk-ws-H.RYRYEHI.MGXi.MEYCIQDfpKR0VFAExe4nYEG-kGoK_bFK1Ovv3HwAiqc9BqWvJAIhAIxC6M2r5u4YhF6YMur-_tfztz4OlQb1shxH0uOyeuQh"